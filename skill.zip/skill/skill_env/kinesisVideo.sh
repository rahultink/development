#!/bin/bash

export AWS_ACCESS_KEY_ID=AKIA2EJX26AUHRP5MPYC
export AWS_SECRET_ACCESS_KEY=kkKmfZo3OKohGQQzpLVfXuC7SOtHwX0ijYJjy/8H
./kinesis-video-native-build/kinesis_video_gstreamer_sample_app rahul-pi -w 640 -h 480 -f 15